class Vehicle {
    void showType() { System.out.println("Vehicle"); }
}
class Car extends Vehicle {
    @Override
    void showType() { System.out.println("Car"); }
}
class Bike extends Vehicle {
    @Override
    void showType() { System.out.println("Bike"); }
}
public class Main {
    public static void main(String[] args) {
        Vehicle[] vehicles = { new Car(), new Bike(), new Car() };
        for (Vehicle v : vehicles) v.showType();
    }
}