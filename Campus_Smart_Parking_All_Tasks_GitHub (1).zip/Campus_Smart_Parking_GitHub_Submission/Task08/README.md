# Task08: Polymorphism

Demonstrates runtime polymorphism through a superclass array and overridden instance methods. Processing n vehicles is O(n), assuming constant-time operations.

## Compile and run
```bash
javac Main.java
java Main
```
