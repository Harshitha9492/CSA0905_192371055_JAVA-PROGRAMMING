# Task02: Parking Data Representation

Demonstrates a two-dimensional array for floors and slots, empty-slot representation, and the difference between integer and floating-point division.

## Compile and run
```bash
javac Main.java
java Main
```
