public class Main {
    public static void main(String[] args) {
        String[][] parking = new String[2][3];
        parking[0][0] = "TN01AB1234";
        parking[1][2] = "TN02CD5678";

        System.out.println("PARKING ARRAY (null = empty)");
        for (int i = 0; i < parking.length; i++) {
            System.out.print("Floor " + (i + 1) + ": ");
            for (int j = 0; j < parking[i].length; j++) {
                System.out.print((parking[i][j] == null ? "EMPTY" : parking[i][j]));
                if (j < parking[i].length - 1) System.out.print(" | ");
            }
            System.out.println();
        }
        int whole = 7 / 2;
        double decimal = 7.0 / 2;
        System.out.println("Integer division 7 / 2 = " + whole);
        System.out.println("Floating division 7.0 / 2 = " + decimal);
    }
}