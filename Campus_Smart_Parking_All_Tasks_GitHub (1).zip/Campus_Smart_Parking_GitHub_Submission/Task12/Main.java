interface PricingRule {
    double calculate(int hours);
}
class CarPricing implements PricingRule {
    public double calculate(int hours) { return hours * 50.0; }
}
class BikePricing implements PricingRule {
    public double calculate(int hours) { return hours * 15.0; }
}
class Vehicle {
    private final String regNo;
    private final PricingRule pricingRule;
    Vehicle(String regNo, PricingRule pricingRule) {
        this.regNo = regNo;
        this.pricingRule = pricingRule;
    }
    double calculateFee(int hours) {
        if (hours < 0) throw new IllegalArgumentException("Hours cannot be negative");
        return pricingRule.calculate(hours);
    }
    String getRegNo() { return regNo; }
}
public class Main {
    public static void main(String[] args) {
        Vehicle car = new Vehicle("TN01AB1234", new CarPricing());
        Vehicle bike = new Vehicle("TN02CD5678", new BikePricing());
        System.out.println(car.getRegNo() + " fee: Rs. " + car.calculateFee(2));
        System.out.println(bike.getRegNo() + " fee: Rs. " + bike.calculateFee(2));
    }
}