abstract class Vehicle {
    protected final String regNo;
    Vehicle(String regNo) { this.regNo = regNo; }
    abstract double calculateFee(int hours);
}
interface Chargeable {
    double chargingFee(double units);
}
class ElectricCar extends Vehicle implements Chargeable {
    ElectricCar(String regNo) { super(regNo); }
    @Override
    double calculateFee(int hours) { return hours * 50.0; }
    @Override
    public double chargingFee(double units) { return units * 8.0; }
}
public class Main {
    public static void main(String[] args) {
        ElectricCar car = new ElectricCar("TN01EV1234");
        System.out.println("Parking fee for 2 hours: Rs. " + car.calculateFee(2));
        System.out.println("Charging fee for 5 units: Rs. " + car.chargingFee(5));
    }
}