# Task05: Static Members and Object Lifecycle

Demonstrates a static counter shared by all ticket objects. This simple counter is not thread-safe and is not persistent across program restarts.

## Compile and run
```bash
javac Main.java
java Main
```
