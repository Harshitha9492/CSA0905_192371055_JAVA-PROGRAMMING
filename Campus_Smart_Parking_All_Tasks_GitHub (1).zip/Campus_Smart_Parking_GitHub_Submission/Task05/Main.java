class ParkingTicket {
    private static int count = 0;
    private final int ticketId;
    ParkingTicket() {
        ticketId = ++count;
    }
    int getTicketId() {
        return ticketId;
    }
}
public class Main {
    public static void main(String[] args) {
        ParkingTicket a = new ParkingTicket();
        ParkingTicket b = new ParkingTicket();
        ParkingTicket c = new ParkingTicket();
        System.out.println("Ticket A: " + a.getTicketId());
        System.out.println("Ticket B: " + b.getTicketId());
        System.out.println("Ticket C: " + c.getTicketId());
        System.out.println("Tickets created: " + 3);
    }
}