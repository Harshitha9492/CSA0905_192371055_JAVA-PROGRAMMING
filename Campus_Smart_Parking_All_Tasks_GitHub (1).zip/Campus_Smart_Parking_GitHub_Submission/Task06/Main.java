class Vehicle {
    protected String regNo;
    Vehicle(String regNo) { this.regNo = regNo; }
    void display() { System.out.println("Vehicle registration: " + regNo); }
}
class Car extends Vehicle {
    Car(String regNo) { super(regNo); }
    void showCategory() { System.out.println("Category: Car"); }
}
class TwoWheeler extends Vehicle {
    TwoWheeler(String regNo) { super(regNo); }
    void showCategory() { System.out.println("Category: Two-wheeler"); }
}
public class Main {
    public static void main(String[] args) {
        Car car = new Car("TN01AB1234");
        TwoWheeler bike = new TwoWheeler("TN02CD5678");
        car.display(); car.showCategory();
        bike.display(); bike.showCategory();
    }
}