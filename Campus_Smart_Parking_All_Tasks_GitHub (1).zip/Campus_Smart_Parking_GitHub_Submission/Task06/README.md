# Task06: Inheritance

Demonstrates inheritance and constructor chaining with super(). See the root README for the conceptual UML relationships.

## Compile and run
```bash
javac Main.java
java Main
```
