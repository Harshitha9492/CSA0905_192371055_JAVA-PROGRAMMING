class ParkingFacility {
    private final String[][] slots;
    ParkingFacility(int floors, int perFloor) {
        slots = new String[floors][perFloor];
    }
    void allocate(String vehicleNo) {
        for (int i = 0; i < slots.length; i++) {
            for (int j = 0; j < slots[i].length; j++) {
                if (slots[i][j] == null) {
                    slots[i][j] = vehicleNo;
                    System.out.println("Allocated " + vehicleNo + " -> Floor " + (i+1) + ", Slot " + (j+1));
                    return;
                }
            }
        }
        System.out.println("Parking Full");
    }
    void release(int floor, int slot) {
        if (floor < 1 || floor > slots.length || slot < 1 || slot > slots[floor-1].length) {
            System.out.println("Invalid Slot");
        } else if (slots[floor-1][slot-1] == null) {
            System.out.println("Slot Already Empty");
        } else {
            System.out.println("Released " + slots[floor-1][slot-1]);
            slots[floor-1][slot-1] = null;
        }
    }
}
public class Main {
    public static void main(String[] args) {
        ParkingFacility p = new ParkingFacility(1, 2);
        p.allocate("TN01AB1234");
        p.allocate("TN02CD5678");
        p.release(1, 1);
        p.allocate("TN03EF9012");
    }
}