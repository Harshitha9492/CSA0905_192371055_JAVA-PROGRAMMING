# Task03: Slot Allocation and Release

Implements first-available-slot allocation and release with bounds checking. Allocation is O(F*S) worst case; releasing a known slot is O(1).

## Compile and run
```bash
javac Main.java
java Main
```
