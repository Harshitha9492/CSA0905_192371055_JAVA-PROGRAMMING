class Vehicle {
    double calculateFee(int hours) { return hours * 20.0; }
}
class Car extends Vehicle {
    @Override
    double calculateFee(int hours) { return hours * 50.0; }
}
class TwoWheeler extends Vehicle {
    @Override
    double calculateFee(int hours) { return hours * 15.0; }
}
public class Main {
    public static void main(String[] args) {
        Vehicle car = new Car();
        Vehicle bike = new TwoWheeler();
        System.out.println("Car fee for 2 hours: Rs. " + car.calculateFee(2));
        System.out.println("Two-wheeler fee for 2 hours: Rs. " + bike.calculateFee(2));
    }
}