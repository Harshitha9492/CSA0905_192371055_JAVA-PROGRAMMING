# Task07: Method Overriding

Demonstrates overriding and dynamic method dispatch. Rates are illustrative and can be changed to match the assignment specification.

## Compile and run
```bash
javac Main.java
java Main
```
