# Task04: Constructors and Copy Constructor

Shows parameterized constructor use and a user-defined copy constructor. The class uses final fields to keep the pass details unchanged after construction.

## Compile and run
```bash
javac Main.java
java Main
```
