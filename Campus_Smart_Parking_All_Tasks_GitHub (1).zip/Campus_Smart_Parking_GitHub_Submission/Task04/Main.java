class ParkingPass {
    private final String owner;
    private final String vehicleNo;

    ParkingPass(String owner, String vehicleNo) {
        this.owner = owner;
        this.vehicleNo = vehicleNo;
    }
    ParkingPass(ParkingPass other) {
        this(other.owner, other.vehicleNo);
    }
    void display() {
        System.out.println("Owner: " + owner + ", Vehicle: " + vehicleNo);
    }
}
public class Main {
    public static void main(String[] args) {
        ParkingPass original = new ParkingPass("Asha", "TN01AB1234");
        ParkingPass copy = new ParkingPass(original);
        System.out.println("Original pass:");
        original.display();
        System.out.println("Copied pass:");
        copy.display();
    }
}