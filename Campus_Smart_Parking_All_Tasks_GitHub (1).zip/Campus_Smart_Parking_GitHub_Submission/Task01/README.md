# Task01: Problem Analysis and Requirements

This task summarizes the problem, inputs, outputs, assumptions, candidate classes and basic complexity. The program prints a compact requirements summary.

## Compile and run
```bash
javac Main.java
java Main
```
