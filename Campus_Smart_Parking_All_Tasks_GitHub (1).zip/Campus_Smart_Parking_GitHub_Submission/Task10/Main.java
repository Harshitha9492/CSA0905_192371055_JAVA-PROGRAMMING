class ParkingSlot {
    private boolean occupied;
    public boolean isOccupied() { return occupied; }
    public void occupy() {
        if (occupied) {
            System.out.println("Cannot occupy: slot is already occupied");
        } else {
            occupied = true;
            System.out.println("Slot occupied");
        }
    }
    public void release() {
        if (!occupied) {
            System.out.println("Cannot release: slot is empty");
        } else {
            occupied = false;
            System.out.println("Slot released");
        }
    }
}
public class Main {
    public static void main(String[] args) {
        ParkingSlot slot = new ParkingSlot();
        slot.occupy();
        slot.occupy();
        slot.release();
        System.out.println("Occupied now: " + slot.isOccupied());
    }
}