# Task10: Encapsulation and Input Validation

Demonstrates encapsulation through a private field and public methods that preserve valid state. Access modifiers and package organization are discussed in the assignment report.

## Compile and run
```bash
javac Main.java
java Main
```
