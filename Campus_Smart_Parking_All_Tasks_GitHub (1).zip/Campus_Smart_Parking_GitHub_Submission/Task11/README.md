# Task11: Integrated System and Test Cases

Small integrated demonstration of allocation, duplicate-registration prevention, release, capacity handling and invalid slot checks. It is a teaching prototype, not a production-ready concurrent system.

## Compile and run
```bash
javac Main.java
java Main
```
