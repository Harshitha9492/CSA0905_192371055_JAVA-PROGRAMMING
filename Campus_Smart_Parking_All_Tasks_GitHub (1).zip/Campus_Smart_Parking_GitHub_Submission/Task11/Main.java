import java.util.HashMap;
import java.util.Map;

class ParkingSystem {
    private final String[] slots;
    private final Map<String, Integer> vehicleSlot = new HashMap<>();
    ParkingSystem(int capacity) { slots = new String[capacity]; }

    void park(String regNo) {
        if (regNo == null || regNo.trim().isEmpty()) {
            System.out.println("Rejected: invalid registration");
            return;
        }
        if (vehicleSlot.containsKey(regNo)) {
            System.out.println("Rejected: vehicle already parked");
            return;
        }
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == null) {
                slots[i] = regNo;
                vehicleSlot.put(regNo, i);
                System.out.println("Parked " + regNo + " in slot " + (i + 1));
                return;
            }
        }
        System.out.println("Parking Full");
    }

    void release(int slotNo) {
        if (slotNo < 1 || slotNo > slots.length) {
            System.out.println("Rejected: invalid slot");
            return;
        }
        String regNo = slots[slotNo - 1];
        if (regNo == null) {
            System.out.println("Slot already empty");
            return;
        }
        slots[slotNo - 1] = null;
        vehicleSlot.remove(regNo);
        System.out.println("Released " + regNo + " from slot " + slotNo);
    }
}
public class Main {
    public static void main(String[] args) {
        ParkingSystem system = new ParkingSystem(2);
        system.park("TN01AB1234");
        system.park("TN02CD5678");
        system.park("TN01AB1234");
        system.release(1);
        system.park("TN03EF9012");
        system.release(9);
    }
}